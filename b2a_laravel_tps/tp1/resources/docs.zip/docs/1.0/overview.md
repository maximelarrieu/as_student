# Projet E-Shop

---

- [PHP Framework : Laravel](/{{route}}/{{version}}/overview/#section-1)

<a name="section-1"></a>
## PHP Framework : Laravel
<p><img src="https://res.cloudinary.com/dtfbvvkyp/image/upload/v1566331377/laravel-logolockup-cmyk-red.svg" width="400"></p>

Découverte du framework PHP Laravel.
Dans le but de développer une application web.
